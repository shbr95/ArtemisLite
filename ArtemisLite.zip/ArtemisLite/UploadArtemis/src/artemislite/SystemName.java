package artemislite;
/**
 * @author curti
 *
 */
public enum SystemName {
	SPACELAUNCHSYS, MANPOWER, SPACECRAFT, HUMANLANDINGSYS, LAUNCHPAD, FREETOUROFNASA;
}
